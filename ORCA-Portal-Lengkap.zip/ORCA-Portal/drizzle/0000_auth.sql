PRAGMA foreign_keys = ON;
CREATE TABLE organizations (
 id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
 npwp TEXT NOT NULL DEFAULT '', nib TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '',
 pic_email TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE roles (
 organization_id TEXT NOT NULL REFERENCES organizations(id), id TEXT NOT NULL,
 name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, permissions TEXT NOT NULL,
 PRIMARY KEY (organization_id,id)
);
CREATE TABLE users (
 id TEXT PRIMARY KEY, organization_id TEXT NOT NULL REFERENCES organizations(id),
 email TEXT NOT NULL UNIQUE COLLATE NOCASE, full_name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
 job_title TEXT NOT NULL DEFAULT '', role_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
 password_hash TEXT NOT NULL, force_password_change INTEGER NOT NULL DEFAULT 0,
 failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
 permanent_lock INTEGER NOT NULL DEFAULT 0, mfa_secret TEXT, mfa_last_step INTEGER NOT NULL DEFAULT -1,
 last_login INTEGER, created_at INTEGER NOT NULL,
 FOREIGN KEY (organization_id,role_id) REFERENCES roles(organization_id,id)
);
CREATE TABLE password_history (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), password_hash TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE INDEX password_history_user ON password_history(user_id,created_at DESC);
CREATE TABLE sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL UNIQUE REFERENCES users(id), csrf_token TEXT NOT NULL,
 created_at INTEGER NOT NULL, last_seen INTEGER NOT NULL, expires_at INTEGER NOT NULL,
 ip TEXT NOT NULL DEFAULT '', user_agent TEXT NOT NULL DEFAULT ''
);
CREATE TABLE auth_challenges (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), secret TEXT NOT NULL,
 csrf_token TEXT NOT NULL, enrollment INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 remember_me INTEGER NOT NULL DEFAULT 0, expires_at INTEGER NOT NULL
);
CREATE TABLE password_resets (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL, used_at INTEGER
);
CREATE TABLE audit_events (
 id TEXT PRIMARY KEY, organization_id TEXT, user_id TEXT, email TEXT NOT NULL DEFAULT '',
 user_name TEXT NOT NULL DEFAULT '', role_id TEXT NOT NULL DEFAULT '', action TEXT NOT NULL,
 module TEXT NOT NULL DEFAULT 'Authentication', entity TEXT NOT NULL DEFAULT '', detail TEXT NOT NULL DEFAULT '',
 result TEXT NOT NULL, ip TEXT NOT NULL DEFAULT '', user_agent TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
);
CREATE INDEX audit_organization_time ON audit_events(organization_id,created_at DESC);
CREATE TABLE workspaces (
 organization_id TEXT PRIMARY KEY REFERENCES organizations(id), data TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
);
CREATE TABLE files (
 id TEXT PRIMARY KEY, organization_id TEXT NOT NULL REFERENCES organizations(id), shipment_id TEXT NOT NULL,
 name TEXT NOT NULL, content_type TEXT NOT NULL, size INTEGER NOT NULL, storage_key TEXT NOT NULL UNIQUE,
 uploaded_by TEXT NOT NULL REFERENCES users(id), created_at INTEGER NOT NULL
);
CREATE TABLE auth_rates (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires_at INTEGER NOT NULL);
