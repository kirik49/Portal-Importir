@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 24 atau lebih baru belum tersedia. Instal Node.js lalu coba lagi.
  pause
  exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<24){console.error('ORCA memerlukan Node.js 24 atau lebih baru.');process.exit(1)}"
if errorlevel 1 (
  pause
  exit /b 1
)
echo Buka http://127.0.0.1:4173 di browser setelah server siap.
echo Tekan Ctrl+C untuk menghentikan server.
node server.cjs
pause
