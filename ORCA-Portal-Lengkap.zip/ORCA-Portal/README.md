# ORCA Importer Portal

A tenant-isolated shipment portal built from the supplied ORCA screen references and the role, login, and registration specification. The supplied logo is preserved in `dist/assets/orca-logo-original.png`.

## Local preview

Requires Node.js 24 or later (for `node:sqlite`). No package install is needed.

```sh
node server.cjs
```

Open `http://127.0.0.1:4173`. The local server stores its SQLite database, uploaded files, and encryption key under ignored `.local/`. It uses the development identity `owner@orca.local` unless `BOOTSTRAP_OWNER_EMAIL` is set. The first visit opens company and Master Admin setup. Use test data only in local preview.

Run the server and syntax checks with:

```sh
node --test tests/*.test.mjs
node --check dist/app.js
node --check dist/auth.js
node --check dist/admin.js
node --check dist/portal-bridge.js
node scripts/build-worker.mjs
node --check dist/server/index.js
```

## Access and onboarding

Sites controls who can open the landing page independently of ORCA. Application login protects all company data and API routes. The Site owner completes the first organization and Master Admin registration with their own company details, password, and authenticator code. There are no production demo credentials and no self-registration route for other users.

Only a tenant's Master Admin can create users. Five fixed roles are created per organization: Master Admin, Admin Importir, Admin Eksportir, Forwarder, and Management. Role permissions can be reduced within their fixed caps; users and all business records remain scoped to their own organization. Extra tenants are provisioned by an operator with a separate secret through `scripts/provision-tenant.mjs`, never by changing organization in the browser. Each new tenant's Master Admin is forced to replace its temporary password and enroll MFA.

Password policy is at least eight characters with uppercase, lowercase, a digit, and a special character; the previous three passwords cannot be reused. Master Admin and Management require TOTP MFA. Failed logins lock a regular user after five attempts and Master Admin after three, for 30 minutes. Sessions expire after 15 minutes of inactivity and a new login revokes the prior session. Login, logout, user administration, and access changes are audited with organization, role, IP, and user agent.

Forgot-password requests use generic responses. If `RESEND_API_KEY` and `MAIL_FROM` are configured as Site secrets, reset links can be emailed. Otherwise a Master Admin can generate a single-use link for a user and deliver it through an approved channel. Links expire after 30 minutes. Do not put passwords or reset links in source files.

## Data and hosting

The production Worker uses D1 (`DB`) for tenant, account, session, audit, and workspace records and R2 (`BUCKET`) for uploaded document bytes. `drizzle/0000_auth.sql` defines the schema. The server validates session, role, tenant, record direction, and revision on every API request and enforces the same limits on uploads and downloads. The browser keeps only presentation preferences locally, not business records or credentials.

The first production workspace starts empty. Old browser-only sample records are not automatically assigned to a company. Shipments, goods, PO allocation, documents, readiness, quotations, settlement, tasks, exceptions, reports, tracking, booking, and customs are available according to the role matrix. Document uploads are limited to 10 MB and the supported formats shown in the UI. Malware scanning and external carrier/customs integrations are not connected.

The Sites deployment uses `.openai/hosting.json`, the Worker bundle in `dist/server/index.js`, the D1 migration in `drizzle/`, and the static frontend in `dist/`. The local preview server is for development only. The current Site access policy must be reviewed separately when inviting users or changing visibility; application user creation does not change Sites access.
