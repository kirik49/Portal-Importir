// Operator tool only. Never accepts keys or passwords in command-line arguments.
// Set ORCA_SITE_URL, ORCA_OPERATOR_KEY and (for private Sites) ORCA_SITES_TOKEN.
// Pipe a JSON object with org, fullName, email, phone, jobTitle, password through stdin.
const site=new URL(process.env.ORCA_SITE_URL||'');
if(site.protocol!=='https:'&&!['127.0.0.1','localhost'].includes(site.hostname))throw new Error('Use HTTPS for the deployed portal.');
if(!/^[a-f0-9]{64}$/i.test(process.env.ORCA_OPERATOR_KEY||''))throw new Error('ORCA_OPERATOR_KEY is required in the operator environment.');
let input='';for await(const chunk of process.stdin)input+=chunk;if(input.length>20000)throw new Error('Input is too large.');
const data=JSON.parse(input),headers={'Content-Type':'application/json','Origin':site.origin,'X-Orca-Operator-Key':process.env.ORCA_OPERATOR_KEY};
if(process.env.ORCA_SITES_TOKEN)headers['OAI-Sites-Authorization']='Bearer '+process.env.ORCA_SITES_TOKEN;
const response=await fetch(new URL('/api/operator/tenants',site),{method:'POST',headers,body:JSON.stringify(data)});
const result=await response.json();
if(!response.ok){process.stderr.write((result.error||'Tenant provisioning failed.')+'\n');process.exitCode=1;}else process.stdout.write(JSON.stringify({organization:result.organization,user:{id:result.user.id,email:result.user.email,roleId:result.user.roleId,forcePasswordChange:result.user.forcePasswordChange}},null,2)+'\n');
