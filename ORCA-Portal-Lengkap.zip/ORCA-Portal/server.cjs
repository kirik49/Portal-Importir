// Local development only. Hosted requests run through the built Cloudflare Worker.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
(async()=>{
 const {handleApi}=await import('./server/auth.mjs');
 const {localDatabase,localBucket}=await import('./server/local-db.mjs');
 const stateDirectory=path.join(__dirname,'.local');fs.mkdirSync(stateDirectory,{recursive:true});
 const keyPath=path.join(stateDirectory,'encryption-key');if(!fs.existsSync(keyPath))fs.writeFileSync(keyPath,crypto.randomBytes(32).toString('hex'),{mode:0o600});
 const env={DB:localDatabase(path.join(stateDirectory,'orca.sqlite'),path.join(__dirname,'drizzle')),BUCKET:localBucket(path.join(stateDirectory,'files')),AUTH_ENCRYPTION_KEY:fs.readFileSync(keyPath,'utf8').trim(),BOOTSTRAP_OWNER_EMAIL:process.env.BOOTSTRAP_OWNER_EMAIL||'owner@orca.local',LOCAL_DEVELOPMENT:'true',RESEND_API_KEY:process.env.RESEND_API_KEY,MAIL_FROM:process.env.MAIL_FROM};
 const root=path.join(__dirname,'dist'),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml'};
 http.createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://'+req.headers.host);
  if(url.pathname.startsWith('/api/')){
   const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>25*1048576){res.writeHead(413);res.end('Request too large');return;}chunks.push(chunk);}
   const headers=new Headers(req.headers);headers.set('oai-authenticated-user-email',env.BOOTSTRAP_OWNER_EMAIL);headers.set('oai-authenticated-user-id','local-owner');headers.set('cf-connecting-ip','127.0.0.1');
   const request=new Request(url,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});
   const response=await handleApi(request,env,{waitUntil:p=>p.catch(console.error)});res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
  }
  const file=path.resolve(root,'.'+(url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname)));
  if(!file.startsWith(root+path.sep)||file.startsWith(path.join(root,'server')+path.sep)||file.includes(path.sep+'.openai'+path.sep)){res.writeHead(404);return res.end('Not found');}
  fs.readFile(file,(error,body)=>{res.writeHead(error?404:200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(error?'Not found':body);});
 }catch(error){console.error(error.message);res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Local server error'}));}}).listen(Number(process.env.PORT)||4173,'127.0.0.1',()=>console.log('ORCA portal http://127.0.0.1:'+(Number(process.env.PORT)||4173)+' · local owner: '+env.BOOTSTRAP_OWNER_EMAIL));
})();
