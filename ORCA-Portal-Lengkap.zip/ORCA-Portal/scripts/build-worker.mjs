import {readFileSync,writeFileSync,readdirSync,mkdirSync,statSync} from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const out=path.join(root,'dist');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
const assets={};
function visit(dir){for(const name of readdirSync(dir)){if(name==='server'||name==='.openai')continue;const file=path.join(dir,name);if(statSync(file).isDirectory())visit(file);else{const key='/'+path.relative(out,file).replaceAll('\\','/');assets[key]={body:readFileSync(file).toString('base64'),type:mime[path.extname(file)]||'application/octet-stream'};}}}
visit(out);
const auth=readFileSync(path.join(root,'server/auth.mjs'),'utf8').replace(/^export\s+(?=(?:async\s+)?(?:function|const|class|let|var)\b)/gm,'');
if(/^import\s/m.test(auth))throw new Error('The dependency-free Worker requires a self-contained auth module.');
const source=`${auth}\nconst ORCA_ASSETS=${JSON.stringify(assets)};\nexport default {async fetch(request,env,ctx){const url=new URL(request.url);if(url.pathname.startsWith('/api/'))return handleApi(request,env,ctx);if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});const asset=ORCA_ASSETS[url.pathname==='/'?'/index.html':url.pathname];if(!asset)return new Response('Not found',{status:404});const bytes=Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0));return new Response(request.method==='HEAD'?null:bytes,{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'}});}};\n`;
mkdirSync(path.join(out,'server'),{recursive:true});
mkdirSync(path.join(out,'.openai'),{recursive:true});
writeFileSync(path.join(out,'server/index.js'),source);
writeFileSync(path.join(out,'.openai/hosting.json'),readFileSync(path.join(root,'.openai/hosting.json')));
console.log(`Built ORCA Worker with ${Object.keys(assets).length} static assets (${Buffer.byteLength(source)} bytes).`);
