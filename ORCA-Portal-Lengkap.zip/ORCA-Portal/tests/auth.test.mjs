import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { handleApi, DEFAULT_PERMISSIONS, hashPassword, totp } from '../server/auth.mjs';

const origin='https://orca.test',password='Strong!Pass123',newPassword='Newer!Pass123';
class D1 {
 constructor(){this.db=new DatabaseSync(':memory:');this.db.exec(readFileSync(new URL('../drizzle/0000_auth.sql',import.meta.url),'utf8'));}
 prepare(sql){const db=this.db;return {params:[],bind(...params){this.params=params;return this;},async first(){return db.prepare(sql).get(...this.params)||null;},async all(){return {results:db.prepare(sql).all(...this.params)};},async run(){const result=db.prepare(sql).run(...this.params);return {success:true,meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}};}};}
 async batch(statements){this.db.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());this.db.exec('COMMIT');return out;}catch(e){this.db.exec('ROLLBACK');throw e;}}
}
async function fixture(){const env={DB:new D1(),AUTH_ENCRYPTION_KEY:'a1'.repeat(32),BOOTSTRAP_OWNER_EMAIL:'owner@example.com'};
 const call=async(path,{method='GET',data,cookie,csrf,headers={}}={})=>{const response=await handleApi(new Request(origin+path,{method,headers:{...(method==='GET'?{}:{Origin:origin,'Content-Type':'application/json'}),...(cookie?{Cookie:cookie}:{}),...(csrf?{'X-Orca-CSRF':csrf}:{}),...headers},body:data?JSON.stringify(data):undefined}),env,{});const payload=await response.json();return {status:response.status,data:payload,cookie:response.headers.get('Set-Cookie')?.split(';')[0],headers:response.headers};};
 const anon=async()=> (await call('/api/auth/status')).data.csrfToken;
 const login=async(email='owner@example.com',pass=password)=>call('/api/auth/login',{method:'POST',data:{email,password:pass},csrf:await anon()});
 const setup=async()=>{const result=await call('/api/auth/setup',{method:'POST',csrf:await anon(),headers:{'oai-authenticated-user-email':'owner@example.com'},data:{org:{code:'PTTEST',name:'PT Test',npwp:'123',nib:'456',address:'Jakarta',picEmail:'owner@example.com'},fullName:'Owner',email:'owner@example.com',phone:'+62123456',jobTitle:'Director',password}});assert.equal(result.status,201,JSON.stringify(result.data));return result.data;};
 const verify=async(challenge)=>call('/api/auth/mfa',{method:'POST',csrf:challenge.csrfToken,data:{challengeId:challenge.challengeId,code:await totp(challenge.secret)}});
 const owner=async()=>{const challenge=await setup(),auth=await verify(challenge);assert.equal(auth.status,200,JSON.stringify(auth.data));return auth;};
 const addUser=async(role='ADMIN_IMPORTIR',em='import@example.com',oid)=>{oid ||= env.DB.db.prepare('SELECT id FROM organizations LIMIT 1').get().id;const id=crypto.randomUUID(),hash=await hashPassword(password);env.DB.db.prepare('INSERT INTO users(id,organization_id,email,full_name,phone,job_title,role_id,password_hash,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(id,oid,em,em,'+62123','Operations',role,hash,Date.now());env.DB.db.prepare('INSERT INTO password_history(id,user_id,password_hash,created_at) VALUES (?,?,?,?)').run(crypto.randomUUID(),id,hash,Date.now());return id;};
 const anotherOrg=()=>{const id=crypto.randomUUID();env.DB.db.prepare('INSERT INTO organizations(id,code,name,pic_email,created_at) VALUES (?,?,?,?,?)').run(id,'OTHER','PT Other','other@example.com',Date.now());for(const [role,p]of Object.entries(DEFAULT_PERMISSIONS))env.DB.db.prepare('INSERT INTO roles(organization_id,id,name,permissions) VALUES (?,?,?,?)').run(id,role,role,JSON.stringify(p));return id;};
 const authOptions=auth=>({cookie:auth.cookie,csrf:auth.data.csrfToken});
 return {env,call,anon,login,setup,verify,owner,addUser,anotherOrg,authOptions};
}

test('bootstrap is owner-only, closes after setup, and Master Admin must enroll MFA before a session',async()=>{
 const f=await fixture();let status=await f.call('/api/auth/status');assert.equal(status.data.setupAllowed,false);
 const allowed=await f.call('/api/auth/status',{headers:{'oai-authenticated-user-email':'owner@example.com'}});assert.equal(allowed.data.setupAllowed,true);
 const denied=await f.call('/api/auth/setup',{method:'POST',csrf:await f.anon(),data:{}});assert.equal(denied.status,403);
 const c=await f.setup();assert.equal(c.mfaRequired,true);assert.equal(c.enrollmentRequired,true);assert.equal((await f.call('/api/workspace')).status,401);
 const auth=await f.verify(c);assert.equal(auth.status,200);assert.equal(auth.data.user.mfaEnabled,true);assert.match(auth.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=Lax/);
 const stored=f.env.DB.db.prepare('SELECT mfa_secret FROM users').get();assert.ok(!stored.mfa_secret.includes(c.secret));assert.match(stored.mfa_secret,/^[a-f0-9]+\.[a-f0-9]+$/);
 status=await f.call('/api/auth/status',{headers:{'oai-authenticated-user-email':'owner@example.com'}});assert.equal(status.data.setupRequired,false);assert.equal(status.data.setupAllowed,false);
 const replay=await f.verify(c);assert.equal(replay.status,401);assert.equal(auth.headers.get('Cache-Control'),'no-store');
});
test('CSRF, exact origin, and temporary-password gate are enforced server-side',async()=>{
 const f=await fixture(),auth=await f.owner();let result=await f.call('/api/admin/users',{method:'POST',cookie:auth.cookie,data:{}});assert.equal(result.status,403);
 result=await f.call('/api/auth/logout',{method:'POST',...f.authOptions(auth),headers:{Origin:'https://evil.test'},data:{}});assert.equal(result.status,403);
 result=await f.call('/api/admin/users',{method:'POST',...f.authOptions(auth),data:{fullName:'Temporary User',email:'temporary@example.com',phone:'+62123',jobTitle:'Staff',roleId:'ADMIN_IMPORTIR',password}});assert.equal(result.status,201);
 const temp=await f.login('temporary@example.com');assert.equal(temp.status,200);assert.equal(temp.data.user.forcePasswordChange,true);result=await f.call('/api/workspace',{...f.authOptions(temp)});assert.equal(result.data.code,'PASSWORD_CHANGE_REQUIRED');
 result=await f.call('/api/auth/password',{method:'POST',...f.authOptions(temp),data:{currentPassword:password,newPassword}});assert.equal(result.status,200);assert.equal(result.data.requiresLogin,true);assert.equal((await f.call('/api/auth/me',{cookie:temp.cookie})).status,401);
});
test('failed authentication locks Master Admin at 3 and other accounts at 5; 30-minute lock auto-expires',async()=>{
 const f=await fixture();await f.owner();const uid=await f.addUser();
 for(let i=0;i<3;i++)assert.equal((await f.login('owner@example.com','Wrong!123')).status,401);
 let owner=f.env.DB.db.prepare("SELECT * FROM users WHERE role_id='MASTER_ADMIN'").get();assert.equal(owner.failed_attempts,3);assert.ok(owner.locked_until>Date.now()+29*60000);assert.equal((await f.login()).status,401);
 for(let i=0;i<4;i++)assert.equal((await f.login('import@example.com','Wrong!123')).status,401);
 let regular=f.env.DB.db.prepare('SELECT * FROM users WHERE id=?').get(uid);assert.equal(regular.locked_until,0);
 await f.login('import@example.com','Wrong!123');regular=f.env.DB.db.prepare('SELECT * FROM users WHERE id=?').get(uid);assert.equal(regular.failed_attempts,5);assert.ok(regular.locked_until>Date.now());
 f.env.DB.db.prepare('UPDATE users SET locked_until=? WHERE id=?').run(Date.now()-1,uid);const auth=await f.login('import@example.com');assert.equal(auth.status,200);regular=f.env.DB.db.prepare('SELECT * FROM users WHERE id=?').get(uid);assert.equal(regular.failed_attempts,0);assert.equal(regular.locked_until,0);
});
test('Master Admin can unlock own-tenant users, permanent locks survive time, and last active master is protected',async()=>{
 const f=await fixture(),owner=await f.owner(),uid=await f.addUser();let result=await f.call(`/api/admin/users/${uid}/lock`,{method:'POST',...f.authOptions(owner),data:{}});assert.equal(result.status,200);assert.equal(result.data.user.permanentLock,true);
 f.env.DB.db.prepare('UPDATE users SET locked_until=? WHERE id=?').run(Date.now()-1,uid);assert.equal((await f.login('import@example.com')).status,401);
 result=await f.call(`/api/admin/users/${uid}/unlock`,{method:'POST',...f.authOptions(owner),data:{}});assert.equal(result.status,200);assert.equal((await f.login('import@example.com')).status,200);
 result=await f.call(`/api/admin/users/${owner.data.user.id}/lock`,{method:'POST',...f.authOptions(owner),data:{}});assert.equal(result.status,400);
});
test('inactive user, organization and role invalidate authentication and existing sessions',async()=>{
 const f=await fixture();await f.owner();const uid=await f.addUser(),auth=await f.login('import@example.com');
 f.env.DB.db.prepare("UPDATE users SET status='inactive' WHERE id=?").run(uid);assert.equal((await f.call('/api/auth/me',{cookie:auth.cookie})).status,401);assert.equal((await f.login('import@example.com')).status,401);
 f.env.DB.db.prepare("UPDATE users SET status='active' WHERE id=?").run(uid);f.env.DB.db.prepare("UPDATE roles SET active=0 WHERE id='ADMIN_IMPORTIR'").run();assert.equal((await f.login('import@example.com')).status,401);
 f.env.DB.db.prepare("UPDATE roles SET active=1 WHERE id='ADMIN_IMPORTIR'").run();f.env.DB.db.prepare('UPDATE organizations SET active=0').run();assert.equal((await f.login('import@example.com')).status,401);
});
test('single active session, 15-minute idle limit, and logout revoke cookies',async()=>{
 const f=await fixture();await f.owner();const uid=await f.addUser(),first=await f.login('import@example.com'),second=await f.login('import@example.com');assert.notEqual(first.cookie,second.cookie);assert.equal((await f.call('/api/auth/me',{cookie:first.cookie})).status,401);assert.equal((await f.call('/api/auth/me',{cookie:second.cookie})).status,200);
 f.env.DB.db.prepare('UPDATE sessions SET last_seen=? WHERE user_id=?').run(Date.now()-15*60000,uid);assert.equal((await f.call('/api/auth/me',{cookie:second.cookie})).data.code,'SESSION_EXPIRED');
 const third=await f.login('import@example.com');assert.equal((await f.call('/api/auth/logout',{method:'POST',...f.authOptions(third),data:{}})).status,200);assert.equal((await f.call('/api/auth/me',{cookie:third.cookie})).status,401);
});
test('Management MFA is mandatory; retry limits and replay protection apply',async()=>{
 const f=await fixture();await f.owner();const uid=await f.addUser('MANAGEMENT','management@example.com'),challenge=await f.login('management@example.com');assert.equal(challenge.data.enrollmentRequired,true);assert.equal(challenge.cookie,undefined);
 const auth=await f.verify(challenge.data);assert.equal(auth.status,200);assert.equal(auth.data.user.mfaRequired,true);
 const next=await f.login('management@example.com'),used=await f.call('/api/auth/mfa',{method:'POST',csrf:next.data.csrfToken,data:{challengeId:next.data.challengeId,code:await totp(challenge.data.secret)}});assert.equal(used.status,401);
 assert.ok(!JSON.stringify(auth.data).includes(challenge.data.secret));assert.equal(f.env.DB.db.prepare('SELECT mfa_last_step FROM users WHERE id=?').get(uid).mfa_last_step,Math.floor(Date.now()/30000));
});
test('password policy and each of last three passwords are rejected; change revokes session',async()=>{
 const f=await fixture();await f.owner();const uid=await f.addUser();let auth=await f.login('import@example.com');
 const change=async(current,next)=>f.call('/api/auth/password',{method:'POST',...f.authOptions(auth),data:{currentPassword:current,newPassword:next}});
 assert.equal((await change(password,'weak')).data.code,'PASSWORD_POLICY');assert.equal((await change(password,password)).data.code,'PASSWORD_REUSE');
 assert.equal((await change(password,newPassword)).status,200);assert.equal((await f.call('/api/auth/me',{cookie:auth.cookie})).status,401);auth=await f.login('import@example.com',newPassword);assert.equal((await change(newPassword,'Third!Pass123')).status,200);auth=await f.login('import@example.com','Third!Pass123');
 for(const old of [password,newPassword,'Third!Pass123'])assert.equal((await change('Third!Pass123',old)).data.code,'PASSWORD_REUSE');assert.equal(f.env.DB.db.prepare('SELECT COUNT(*) n FROM password_history WHERE user_id=?').get(uid).n,3);
});
test('forgot password is generic without mail configuration; authorized reset links expire and are single-use',async()=>{
 const f=await fixture(),owner=await f.owner(),uid=await f.addUser(),auth=await f.login('import@example.com');
 const unknown=await f.call('/api/auth/forgot',{method:'POST',csrf:await f.anon(),data:{email:'unknown@example.com'}}),known=await f.call('/api/auth/forgot',{method:'POST',csrf:await f.anon(),data:{email:'import@example.com'}});assert.deepEqual(unknown.data,known.data);assert.equal(known.data.recoveryAvailable,false);assert.equal(f.env.DB.db.prepare('SELECT COUNT(*) n FROM password_resets').get().n,0);
 let link=await f.call(`/api/admin/users/${uid}/reset-link`,{method:'POST',...f.authOptions(owner),data:{}});assert.equal(link.status,200);let token=new URL(link.data.resetUrl).searchParams.get('reset');let reset=await f.call('/api/auth/reset',{method:'POST',csrf:await f.anon(),data:{token,password:newPassword}});assert.equal(reset.status,200);assert.equal((await f.call('/api/auth/me',{cookie:auth.cookie})).status,401);reset=await f.call('/api/auth/reset',{method:'POST',csrf:await f.anon(),data:{token,password:'Fourth!Pass123'}});assert.equal(reset.status,400);
 link=await f.call(`/api/admin/users/${uid}/reset-link`,{method:'POST',...f.authOptions(owner),data:{}});token=new URL(link.data.resetUrl).searchParams.get('reset');f.env.DB.db.prepare('UPDATE password_resets SET expires_at=?').run(Date.now()-1);reset=await f.call('/api/auth/reset',{method:'POST',csrf:await f.anon(),data:{token,password:'Fourth!Pass123'}});assert.equal(reset.data.code,'RESET_INVALID');
});
test('tenant boundaries protect users, organization, files, roles and workspace records',async()=>{
 const f=await fixture(),owner=await f.owner(),other=f.anotherOrg(),otherUser=await f.addUser('ADMIN_IMPORTIR','other@example.com',other);let result=await f.call(`/api/admin/users/${otherUser}`,{method:'PATCH',...f.authOptions(owner),data:{fullName:'Hijacked'}});assert.equal(result.status,404);
 result=await f.call('/api/admin/users',{...f.authOptions(owner)});assert.ok(!result.data.users.some(u=>u.id===otherUser));result=await f.call('/api/admin/organization',{method:'PATCH',...f.authOptions(owner),data:{id:other,name:'Hijacked'}});assert.equal(result.status,403);
 const current=await f.call('/api/workspace',{...f.authOptions(owner)});assert.equal(current.data.workspace.shipments.length,0);const otherAuth=await f.login('other@example.com');assert.equal((await f.call('/api/admin/users',{...f.authOptions(otherAuth)})).status,403);assert.equal((await f.call('/api/workspace',{...f.authOptions(otherAuth)})).data.workspace.org,'PT Other');
 result=await f.call('/api/admin/roles/FORWARDER',{method:'PATCH',...f.authOptions(owner),data:{permissions:{...DEFAULT_PERMISSIONS.FORWARDER,users:'full'}}});assert.equal(result.data.code,'ROLE_PERMISSION_CAP');
 result=await f.call('/api/admin/roles/MASTER_ADMIN',{method:'PATCH',...f.authOptions(owner),data:{active:false}});assert.equal(result.data.code,'MASTER_ROLE_PROTECTED');
});

async function workspaceFixture(){const f=await fixture(),owner=await f.owner();await f.addUser('ADMIN_IMPORTIR','import@example.com');await f.addUser('ADMIN_EKSPORTIR','export@example.com');await f.addUser('FORWARDER','forward@example.com');const current=await f.call('/api/workspace',{...f.authOptions(owner)}),w=current.data.workspace;w.shipments=[{id:'I1',direction:'import',exporter:'Import supplier',origin:'China',destination:'Jakarta',eta:'2026-12-20',status:'In Preparation',booking:true,bookingReference:'PRIVATE-BOOKING',customsStatus:'Pending'},{id:'E1',direction:'export',exporter:'Secret export supplier',origin:'Jakarta',destination:'Japan',eta:'2026-12-21',status:'In Transit',booking:false}];w.goods=[{id:'G1',shipment:'I1',name:'Import goods'},{id:'G2',shipment:'E1',name:'Secret export goods'}];w.costs=[{id:'C1',shipment:'I1',category:'Freight',amount:1}];const saved=await f.call('/api/workspace',{method:'POST',...f.authOptions(owner),data:{workspace:w,revision:current.data.revision}});assert.equal(saved.status,200,JSON.stringify(saved.data));return {...f,owner};}
test('direction-denied records are filtered, protected fields redacted, and hidden data survives visible snapshots',async()=>{
 const f=await workspaceFixture(),auth=await f.login('import@example.com'),current=await f.call('/api/workspace',{...f.authOptions(auth)}),w=current.data.workspace;assert.equal(w.goods.length,1);assert.ok(!JSON.stringify(w).includes('Secret export'));assert.ok(!JSON.stringify(w).includes('PRIVATE-BOOKING'));assert.equal(w.shipments.length,2);assert.equal(w.shipments.find(s=>s.id==='E1').exporter,undefined);
 w.goods[0].name='Changed import goods';let saved=await f.call('/api/workspace',{method:'POST',...f.authOptions(auth),data:{workspace:w,revision:current.data.revision}});assert.equal(saved.status,200,JSON.stringify(saved.data));const canonical=await f.call('/api/workspace',{...f.authOptions(f.owner)});assert.equal(canonical.data.workspace.goods.find(g=>g.id==='G2').name,'Secret export goods');assert.equal(canonical.data.workspace.shipments.find(s=>s.id==='I1').bookingReference,'PRIVATE-BOOKING');
 w.shipments.find(s=>s.id==='I1').booking=true;saved=await f.call('/api/workspace',{method:'POST',...f.authOptions(auth),data:{workspace:w,revision:saved.data.revision}});assert.equal(saved.status,403);
});
test('server rejects direction reassignment, unauthorized booking/customs, cascades and stale revisions',async()=>{
 const f=await workspaceFixture(),auth=await f.login('import@example.com'),current=await f.call('/api/workspace',{...f.authOptions(auth)});
 const save=async(w,revision=current.data.revision)=>f.call('/api/workspace',{method:'POST',...f.authOptions(auth),data:{workspace:w,revision}});
 let w=structuredClone(current.data.workspace);w.goods[0].shipment='E1';assert.equal((await save(w)).status,403);
 w=structuredClone(current.data.workspace);w.costs[0].category='Customs';assert.equal((await save(w)).status,403);
 w=structuredClone(current.data.workspace);w.shipments.find(s=>s.id==='I1').customsStatus='Cleared';assert.equal((await save(w)).status,403);
 w=structuredClone(current.data.workspace);w.shipments=w.shipments.filter(s=>s.id!=='I1');w.goods=[];w.costs=[];assert.equal((await save(w)).status,403);
 assert.equal((await save(current.data.workspace,-1)).status,409);
});
test('Forwarder can track/book/clear customs but cannot create shipments or edit goods/business metadata',async()=>{
 const f=await workspaceFixture(),auth=await f.login('forward@example.com'),current=await f.call('/api/workspace',{...f.authOptions(auth)}),w=current.data.workspace;w.shipments[0].status='In Transit';w.shipments[0].trackingNote='Departed';w.shipments[0].bookingReference='FORWARDER-BOOKING';w.shipments[0].customsStatus='Cleared';let saved=await f.call('/api/workspace',{method:'POST',...f.authOptions(auth),data:{workspace:w,revision:current.data.revision}});assert.equal(saved.status,200,JSON.stringify(saved.data));
 for(const mutate of [x=>x.goods[0].name='Hijack',x=>x.shipments[0].exporter='Hijack',x=>x.shipments.push({id:'I2',direction:'import',booking:false}),x=>x.shipments[0].eta='2027-01-01']){const next=structuredClone(saved.data.workspace);mutate(next);const r=await f.call('/api/workspace',{method:'POST',...f.authOptions(auth),data:{workspace:next,revision:saved.data.revision}});assert.equal(r.status,403,JSON.stringify(r.data));}
});
test('file upload/download obey tenant, direction and customs permissions, and support Unicode filenames',async()=>{
 const f=await workspaceFixture(),objects=new Map();f.env.BUCKET={async put(key,bytes){objects.set(key,bytes);},async get(key){return objects.has(key)?{body:objects.get(key)}:null;}};
 const upload=async(auth,category,name='发票📄.pdf')=>{const form=new FormData();form.set('file',new File(['test document'],name,{type:'application/pdf'}));form.set('shipment','I1');form.set('category',category);const response=await handleApi(new Request(origin+'/api/files',{method:'POST',headers:{Origin:origin,Cookie:auth.cookie,'X-Orca-CSRF':auth.data.csrfToken},body:form}),f.env,{});return {status:response.status,data:await response.json()};};
 const normal=await upload(f.owner,'Commercial'),customs=await upload(f.owner,'Customs');assert.equal(normal.status,201);assert.equal(customs.status,201);
 const importer=await f.login('import@example.com');assert.equal((await upload(importer,'Customs')).status,403);assert.equal(objects.size,2);
 let current=await f.call('/api/workspace',{...f.authOptions(f.owner)});current.data.workspace.docs.push(normal.data.file,customs.data.file);let saved=await f.call('/api/workspace',{method:'POST',...f.authOptions(f.owner),data:current.data});assert.equal(saved.status,200);
 await f.addUser('MANAGEMENT','view@example.com');const managementChallenge=await f.login('view@example.com'),management=await f.verify(managementChallenge.data);
 const download=async(auth,id)=>handleApi(new Request(origin+`/api/files/${id}`,{headers:{Cookie:auth.cookie}}),f.env,{});
 let response=await download(management,normal.data.file.id);assert.equal(response.status,200);assert.match(response.headers.get('Content-Disposition'),/filename\*=UTF-8''/);assert.equal(await response.text(),'test document');assert.equal((await download(management,customs.data.file.id)).status,403);
 const other=f.anotherOrg();await f.addUser('ADMIN_IMPORTIR','other-files@example.com',other);const outsider=await f.login('other-files@example.com');assert.equal((await download(outsider,normal.data.file.id)).status,404);
});
test('deployment operator can provision a separate PT; ordinary Master Admin cannot cross the operator boundary',async()=>{
 const f=await fixture(),owner=await f.owner();f.env.TENANT_PROVISIONING_KEY='b2'.repeat(32);const input={org:{code:'PTB',name:'PT B',npwp:'123',nib:'456',address:'Bandung',picEmail:'masterb@example.com'},fullName:'Master B',email:'masterb@example.com',phone:'+62123',jobTitle:'Owner',password};
 let result=await f.call('/api/operator/tenants',{method:'POST',...f.authOptions(owner),data:input});assert.equal(result.status,401);result=await f.call('/api/operator/tenants',{method:'POST',headers:{'X-Orca-Operator-Key':f.env.TENANT_PROVISIONING_KEY},data:input});assert.equal(result.status,201,JSON.stringify(result.data));assert.equal(result.data.user.roleId,'MASTER_ADMIN');assert.equal(result.data.user.forcePasswordChange,true);assert.ok(!JSON.stringify(result.data).includes(password));
 const list=await f.call('/api/admin/users',{...f.authOptions(owner)});assert.equal(list.data.users.length,1);const challenge=await f.login('masterb@example.com');assert.equal(challenge.data.enrollmentRequired,true);const second=await f.verify(challenge.data);assert.equal(second.status,200);assert.equal(second.data.organization.code,'PTB');assert.equal((await f.call('/api/workspace',{cookie:second.cookie})).data.code,'PASSWORD_CHANGE_REQUIRED');
});
